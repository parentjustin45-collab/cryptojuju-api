import express from "express";
import cors from "cors";

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

app.get("/", (_req, res) => {
  res.json({
    name: "CryptoJuju API",
    status: "online",
    endpoints: ["/health", "/candles?symbol=BTCUSDT&interval=6h&limit=500"]
  });
});

app.get("/health", (_req, res) => {
  res.json({
    ok: true,
    service: "cryptojuju-api",
    time: new Date().toISOString()
  });
});

// First Bitunix server-side test.
// We keep the Bitunix URL in one place so it is easy to adjust if their
// public market endpoint format differs from the current API documentation.
const BITUNIX_BASE = process.env.BITUNIX_BASE_URL || "https://fapi.bitunix.com";

app.get("/candles", async (req, res) => {
  try {
    const symbol = String(req.query.symbol || "BTCUSDT").toUpperCase();
    const interval = String(req.query.interval || "6h");
    const requestedLimit = Math.min(Math.max(Number(req.query.limit) || 500, 1), 500);

    // Bitunix public kline endpoint. The backend makes this request,
    // so the browser no longer needs a public CORS proxy.
    const url = new URL("/api/v1/futures/market/kline", BITUNIX_BASE);
    url.searchParams.set("symbol", symbol);
    url.searchParams.set("interval", interval);
    url.searchParams.set("limit", String(requestedLimit));

    const upstream = await fetch(url, {
      headers: {
        "Accept": "application/json",
        "User-Agent": "CryptoJuju-API/1.0"
      }
    });

    const text = await upstream.text();

    if (!upstream.ok) {
      return res.status(502).json({
        ok: false,
        source: "Bitunix",
        upstreamStatus: upstream.status,
        message: "Bitunix request failed",
        details: text.slice(0, 1000)
      });
    }

    let data;
    try {
      data = JSON.parse(text);
    } catch {
      return res.status(502).json({
        ok: false,
        source: "Bitunix",
        message: "Bitunix returned a non-JSON response",
        details: text.slice(0, 1000)
      });
    }

    res.json({
      ok: true,
      source: "Bitunix",
      symbol,
      interval,
      requestedLimit,
      data
    });
  } catch (error) {
    res.status(500).json({
      ok: false,
      message: "CryptoJuju API error",
      error: error instanceof Error ? error.message : String(error)
    });
  }
});

app.listen(PORT, () => {
  console.log(`CryptoJuju API listening on port ${PORT}`);
});
